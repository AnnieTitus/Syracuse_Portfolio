#Airline Data Analysis
#IST 687 
#Name: Annie Titus

# Packages installed
library(readxl)
library(moments)
library(tidyverse)
library("kernlab")
library("e1071")
library("ggplot2")


# Importing the Satisfaction survey dataset
Copy_of_Satisfaction_Survey_2_Final_Project <- read_excel("C:/Users/annie/Desktop/IST 687 Applied Data Science/Copy of Satisfaction Survey(2)_Final Project.xlsx")
View(Copy_of_Satisfaction_Survey_2_Final_Project)
#Removing NAs
SatSurvey<-na.omit(Copy_of_Satisfaction_Survey_2_Final_Project)
#Reviewing the structure of the new dateset 
str(SatSurvey)


#Going to look at relationships between attributes and identified trends and correlations within the dataset

#Histogram of Satisfaction 
ggplot(SatSurvey, aes(x=Satisfaction))+geom_histogram(bins = 5, color="black", fill="white")

#Creating function to view measure of spread for the attributes
printInfo<-function(v){
  cat("mean",mean(v), "\n")
  cat("median", median (v), "\n")
  cat("min", min(v), "\n")
  cat("max", max(v), "\n")
  cat ("sd", sd(v), "\n")
  cat ("quantile(0.05,0.95))", quantile(v, c(0.05, .95)), "\n")
  cat ("skewness", skewness(v), "\n")
}


#measure of spread for Satisfaction
S<-SatSurvey$Satisfaction
printInfo(S)

#Histogram of Age 
ggplot(SatSurvey, aes(x=Age))+geom_histogram(binwidth = 1, color="black", fill="white")

#measure of spread for Age
A<-SatSurvey$Age
printInfo(A)

#Histogram of No of flights P.a.
ggplot(SatSurvey, aes(x= `No of Flights p.a.`))+geom_histogram(binwidth = 1, color="black", fill="white")

#measure of spread for No of Flights p.a.
N<-SatSurvey$`No of Flights p.a.`
printInfo(N)

#Histogram of Scheduled Departure Hour
ggplot(SatSurvey, aes(x=`Scheduled Departure Hour`))+geom_histogram(binwidth = 1, color="black", fill="white")

#measure of spread for Scheduled Departure Hour
D<-(SatSurvey$`Scheduled Departure Hour`)
printInfo(D)
#------------------------------------------------------------------------------

#creating a  chart for Airline Name compare to Satisfaction

SatMean<-tapply(SatSurvey$Satisfaction, SatSurvey$`Airline Name`, mean)
Airline<-names(SatMean)
Airline.Satisfaction<-data.frame(Airline, SatMean)

ggplot(Airline.Satisfaction, aes(y=Airline, x =SatMean))+geom_bar(stat="identity")

#--------------------------------------------------------------------------------

#-------------------------------------------------------------------
#creating a bar chart for Airline Name compare to Arrival Delay in Mins
AirlineName<-unique(SatSurvey$`Airline Name`)
Arrival.Flight.Delay.Mean<-tapply(SatSurvey$`Arrival Delay in Minutes`, SatSurvey$`Airline Name`, mean)
Airline.Delay<-data.frame(Flight.Delay.Mean)

select(SatSurvey, `Airline Name`, `Arrival Delay in Minutes`)
SatSurvey %>% select( `Airline Name`, `Arrival Delay in Minutes`)

AirlineFlightDelay<-SatSurvey %>%
  group_by(`Airline Name`) %>% 
  summarise(Arrival.Flight.Delay.Mean=mean(`Arrival Delay in Minutes`))

AirlineFlightDelay %>% 
  ggplot(aes(y=`Airline Name`, x=Arrival.Flight.Delay.Mean))+
  geom_bar(stat="identity")+
  theme(axis.text.x =element_text(angle=55, hjust=1))

#--------------------------------------------------------------------------------
#Graphing Satisfaction and Arrival Delay in Minutes
ArrivalDelay<-SatSurvey %>% 
  group_by(Satisfaction) %>% 
  summarise(Arrival.Flight.Delay.Mean=mean(`Arrival Delay in Minutes`))

ArrivalDelay %>% 
  ggplot(aes(x=Satisfaction, y=Arrival.Flight.Delay.Mean))+
  geom_bar(stat="identity")+
  stat_smooth(method = "lm", col="red")

#Linear model between Arrival flight delay (Mins) to Satisfaction
X<-lm(formula=Satisfaction~Arrival.Flight.Delay.Mean,data=ArrivalDelay)
summary(X)
#-----------------------------------------------------------------------------

#Creating a scatterplot between mean of Satisfaction and flight date and plotting an Abline
SatMean<-tapply(SatSurvey$Satisfaction, SatSurvey$`Flight date`, mean)
Flight.date<-as.Date(names(SatMean), "%Y-%m-%d")

sat.flight<-data.frame(SatMean, Flight.date)

ggplot(sat.flight, aes(y=Flight.date, x=SatMean)) + geom_point()+ geom_line()+
  stat_smooth(method = "lm", col="red")

#Using Linear Model to see the significants of Flight Date
x<-lm(formula=SatMean~Flight.date, data=sat.flight)
summary(x)

#---------------------------------------------------------------------------
#Creating scatterplot between Satisfaction to Gender, colored by Age
ggplot(SatSurvey, aes(x=Satisfaction, y=Gender))+ geom_point(aes(size=2, color = Age))+
  stat_smooth(method = "lm", col="red")

#Creating a jitter point to view Satisfaction to Gender and Age
ggplot(SatSurvey, aes(x=Satisfaction, y=Age))+ 
  geom_jitter(aes(color=Gender),size=2, alpha=.2)+ 
  stat_smooth(method = "lm", col="red")

#Creating a boxplot to view Satisfaction to Gender and Age
ggplot(SatSurvey, aes(x=factor(Satisfaction), y=Age, color=Gender))+ 
  geom_boxplot()+
  facet_wrap(~Gender)

#looking at the linear model between Satisfaction ~ Age
plot(SatSurvey$Satisfaction, SatSurvey$Age)
Y<-lm(formula=Satisfaction~Age, data=SatSurvey)
summary(Y)

#looking at the linear model between Satisfaction ~ Age + Gender
AG<-lm(formula=Satisfaction~Age+Gender, data=SatSurvey)
summary(AG)

#-------------------------------------------------------------------------------

#Wanted to creat smaller subset dataset for later data analysis

#Subset dataset for Male and Female

Male<-subset(SatSurvey, SatSurvey$Gender=='Male')

Female<-subset(SatSurvey, SatSurvey$Gender=='Female')

#creating a subset dataset for WestAirways and GoingNorthAirlines since their flights have the highest and Lowest satisfactions
WestAirways <- subset(SatSurvey, SatSurvey$`Airline Name`=='West Airways Inc.')

GoingNorthAirlinesInc<-subset(SatSurvey, SatSurvey$`Airline Name`=='GoingNorth Airlines Inc.')

#creating a subset group of data for Satisfaction >= 3.5

Greater3.5<-SatSurvey %>% 
  filter(Satisfaction>=3.5)

#Subset dataset of Satisfaction less then 3.0

Lessthen3.5<-SatSurvey %>% 
  filter(Satisfaction<3.5)
#----------------------------------------------------------------------
#creating a bar graph between price sensitivity and Age
ggplot(SatSurvey, aes(x=Age, y=`Price Sensitivity`))+geom_bar(stat="identity")

AgeSensitivity<-tapply(SatSurvey$Age, SatSurvey$`Price Sensitivity`, mean)
Price.Sensitivity<-names(AgeSensitivity)
PriceSensitivity.Age<-data.frame(Price.Sensitivity, AgeSensitivity)
ggplot(PriceSensitivity.Age, aes(x=Price.Sensitivity, y=AgeSensitivity))+geom_bar(stat="identity")

#---------------------------------------------------------------------------

#Linear Model Dependent Variable - Satisfaction, Independent Variables - all variables witha  customer score or a metric 

LM1<-lm(formula = Satisfaction~Age
        +`Price Sensitivity`
        +`Year of First Flight`
        +`No of Flights p.a.`
        +`% of Flight with other Airlines`
        +`No. of other Loyalty Cards`
        +`Shopping Amount at Airport`
        +`Eating and Drinking at Airport`
        +`Day of Month`
        +`Flight date`
        +`Scheduled Departure Hour`
        +`Departure Delay in Minutes`
        +`Arrival Delay in Minutes`
        +`Flight time in minutes`
        +`Flight Distance`
        , data=GoingNorthAirlinesInc)

summary(LM1)

#---------------------------------------------------------------------------

#Removing independent variables that are not significant 
LM2<-lm(formula = Satisfaction~Age
        +`Price Sensitivity`
        +`No of Flights p.a.`
        +`Eating and Drinking at Airport`
        +`Arrival Delay in Minutes`
        , data=GoingNorthAirlinesInc)

summary(LM2)
#-----------------------------------------------------------------------------
# removed Eating and Drinking at Airport as a variable due to lowest significant

LM3<-lm(formula = Satisfaction~Age
        +`Price Sensitivity`
        +`Arrival Delay in Minutes`
        +`No of Flights p.a.`
        , data=GoingNorthAirlinesInc)

summary(LM3)
#plotting all independent and dependent variables
ggplot(GoingNorthAirlinesInc, aes(x=`Price Sensitivity`, y=Satisfaction, size = `Arrival Delay in Minutes`, col=Age, alpha = `No of Flights p.a.`))+geom_jitter(width=.05, height=1) + geom_abline()+labs(x="Price Sensitivity", y="Satisfaction")

#Plotting the significant variables against satisfaction to show better visuals
ggplot(GoingNorthAirlinesInc, aes(x=as.factor(`Price Sensitivity`), y=Satisfaction))+ geom_boxplot()

ggplot(GoingNorthAirlinesInc, aes(y=`Arrival Delay in Minutes`, x=Satisfaction))+ geom_bar(stat="identity")

ggplot(GoingNorthAirlinesInc, aes(x=Age, y=Satisfaction))+ geom_jitter()

ggplot(GoingNorthAirlinesInc, aes(x=`No of Flights p.a.`, y=Satisfaction))+ geom_point()

ggplot(GoingNorthAirlinesInc, aes(x=`Eating and Drinking at Airport`, y=Satisfaction))+ geom_jitter()

#------------------------------------------------------------------------------

#KSVM Modeling


#creating a subset dataset for GoingNorthAirlines since their flights have the Lowest satisfactions

GoingNorthAirlinesInc<-subset(SatSurvey, SatSurvey$`Airline Name`=='GoingNorth Airlines Inc.')

#creating a subset group of data for Satisfaction >= 3.5

Greater3.5<-GoingNorthAirlinesInc %>% 
  filter(Satisfaction>=3.5)

#Subset dataset of Satisfaction less then 3.0

Lessthen3.5<-GoingNorthAirlinesInc %>% 
  filter(Satisfaction<3.5)

#Creating a target to identified when satisfaction is greater then 3.5 and when it's less then 3.5
GoingNorthAirlinesInc$target<-ifelse(GoingNorthAirlinesInc$Satisfaction>3.5,1,0)


#Create train and test data  to predict Satisfaction
ranIndex<-sample(1:dim(GoingNorthAirlinesInc)[1])
head(ranIndex) # first random row


#In order to split the data, create a 2/3 cutpoint and round the number
cutpoint2_3<-floor(2*dim(GoingNorthAirlinesInc)[1]/3)

#create train data set, which contains the first 2/3 of the overall data
trainData<-GoingNorthAirlinesInc[ranIndex[1:cutpoint2_3],]
dim(trainData)
head(trainData)

#create test data, which contains the left 1/3 of the overall data

testdata<-GoingNorthAirlinesInc[ranIndex[(cutpoint2_3+1):dim(GoingNorthAirlinesInc)[1]],]
dim(testdata)
head(testdata)

#Building a Model using KSVM & plotting the results looking at just one airline
svmOutput<-ksvm(target~Age
                +`Price Sensitivity`
                +`Year of First Flight`
                +`No of Flights p.a.`
                +`% of Flight with other Airlines`
                +`No. of other Loyalty Cards`
                +`Shopping Amount at Airport`
                +`Eating and Drinking at Airport`
                +`Day of Month`
                +`Flight date`
                +`Scheduled Departure Hour`
                +`Departure Delay in Minutes`
                +`Arrival Delay in Minutes`
                +`Flight time in minutes`
                +`Flight Distance`, data=GoingNorthAirlinesInc)
svmOutput

#Test the model on the testing dataset
svmPred<-predict(svmOutput, testdata, type="response")
str(svmPred)
head(svmPred)

comptable<-data.frame(testdata$target, svmPred[,1])
#update comptable column names to "test" and "Pred"
colnames(comptable)<-c("test", "Pred")
head(comptable)

#putting a table of the target and svmPred
table(testdata$target, svmPred[,1])
svmPred1<-predict(svmOutput, testdata)
head(svmPred1)
testdata$Prob<-svmPred[,1]

#Creating a pred column of below .50 (below satisfaction) 
#and greater than .50 (above Satisfaction)
testdata$Pred<-ifelse(testdata$Prob>0.5,1,0)

comptable$error<-abs(comptable$test-comptable$Pred)

table(testdata$target,testdata$Pred)
Accuracy<-(202+197)/(202+83+39+197)
Accuracy

#----------------------------------------------------------------------------
#creating model using Naive Bayes
NBOutput2<-naiveBayes(as.factor(target)~Age
                      +`Price Sensitivity`
                      +`Year of First Flight`
                      +`No of Flights p.a.`
                      +`% of Flight with other Airlines`
                      +`No. of other Loyalty Cards`
                      +`Shopping Amount at Airport`
                      +`Eating and Drinking at Airport`
                      +`Day of Month`
                      +`Flight date`
                      +`Scheduled Departure Hour`
                      +`Departure Delay in Minutes`
                      +`Arrival Delay in Minutes`
                      +`Flight time in minutes`
                      +`Flight Distance`, data=GoingNorthAirlinesInc)
NBOutput2


#since i created two additional columns in the testdata for KSVM, 
#i needed to put that into another variable so i could use the testdata for NB
KSVMtestData<-testdata
#creating a new testdata set for NB model
NBTestData<-testdata[,1:29]
NBPred<-predict(NBOutput2, NBTestData)
NBPred
head(NBPred)


table(testdata$target, NBPred)
#reviewing the accuracy of the model
Accuracy<-(190+178)/(190+95+58+178)
Accuracy

#### Modeling end ####

#################################################################################################

